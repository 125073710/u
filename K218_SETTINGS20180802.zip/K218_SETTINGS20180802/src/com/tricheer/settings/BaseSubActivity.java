package com.tricheer.settings;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 适合带有返回按键和标题的activity
 * 重写onBack()方法，可以监听到虚拟返回按键事件</p>
 * 使用setTitleString(String)定制标题</p>
 * 使用needRefreshIcon(boolean)选择选择是否需要刷新按钮,重写onRefresh()方法监听刷新图标事件
 * @author zhaopengfei
 *
 */
public class BaseSubActivity extends Activity {
	private Button mback;
	private Button mRefresh;
	private TextView mTitle;
	private LinearLayout contentLayout;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.setContentView(R.layout.activity_base_layout);
		bindView();

	}

	private void bindView() {
		// TODO Auto-generated method stub
		mback = (Button) findViewById(R.id.activity_back);
		mTitle = (TextView) findViewById(R.id.activity_title);
		contentLayout = (LinearLayout) findViewById(R.id.content_view);
		mRefresh = (Button) findViewById(R.id.activity_refresh);
		mback.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// finish();
				onBack();
			}
		});
		mRefresh.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				onRefresh();
			}
		});
		setTitleString("自定义标题");
	}

	@Override
	public void setContentView(int layoutResID) {
		// TODO Auto-generated method stub
		setContentView(View.inflate(this, layoutResID, null));
	}

	@Override
	public void setContentView(View view) {
		// TODO Auto-generated method stub
		if (contentLayout != null) {
			contentLayout.addView(view, new LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		}
	}

	public final  void setTitleString(String title) {
		if (mTitle != null) {
			mTitle.setText(title);
		}
	}

	public final void needRefreshIcon(boolean need) {
		if (mRefresh != null) {
			if (need) {
				mRefresh.setVisibility(View.VISIBLE);
			} else {
				mRefresh.setVisibility(View.GONE);
			}
		}
	}

	public  void onBack() {
		finish();
	}

	public void onRefresh() {

	}
}
