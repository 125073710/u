package com.tricheer.settings.util;

import com.orhanobut.logger.Logger;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.provider.Settings;

public class UtilSetting {
	// Setting 数据库中写值
	public static void setdata(Context cxt, String key, int value) {
		try {
			Settings.Global.putInt(cxt.getContentResolver(), key, value);
		} catch (Exception e) {
			if (e != null) {
				Logger.e("setting save data = " + value);
			}
		}
	}

	// Setting 数据库中读取值
	public static int getdata(Context cxt, String key) {
		try {
			return Settings.Global.getInt(cxt.getContentResolver(), key, -1);
		} catch (Exception e) {
			if (e != null) {
				Logger.i("getRecorderRear(Context)> " + e.getMessage());
			}
		}
		return 0;
	}
	
	
	public static void setShareprefer(Context context,String key ,int tag){
		  SharedPreferences sharedPreferences =context.getSharedPreferences(key, Context.MODE_PRIVATE);  
		    Editor editor = sharedPreferences.edit();  
		    editor.putInt(key, tag);  
		    editor.commit();
	}
	
	public static int getShareperfer(Context context,String key){
		 SharedPreferences sharedPreferences = context.getSharedPreferences(key, Context.MODE_PRIVATE);  
		    int tag = sharedPreferences.getInt(key, 0); 
		    return tag;
	}
	  
}
