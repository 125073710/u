package com.tricheer.settings.bluetooth;

import android.content.Context;
import android.net.Uri;
import android.provider.Settings;

public class BTSettingsGlobal {
	/**自动接听 自定义的系统settings Global 值*/
	public static final String TRI_BT_AUTO_ACCEPT = "tri_bt_auto_accept";
	/**自动连接 自定义的系统settings Global 值*/
	public static final String TRI_BT_AUTO_CONNECT = "tri_bt_auto_connect";
	/**自动同步联系人 自定义的系统settings Global 值*/
	public static final String TRI_BT_AUTO_SYNC_PB = "tri_bt_auto_sync_pb";
	/**自动同步通话记录 自定义的系统settings Global 值*/
	public static final String TRI_BT_AUTO_SYNC_LOG = "tri_bt_auto_sync_log";
	public static final Uri URI_TRI_BT_AUTO_ACCEPT = Settings.Global
			.getUriFor(TRI_BT_AUTO_ACCEPT);
	public static final Uri URI_TRI_BT_AUTO_CONNECT = Settings.Global
			.getUriFor(TRI_BT_AUTO_CONNECT);
	public static final Uri URI_TRI_BT_AUTO_SYNC_PB = Settings.Global
			.getUriFor(TRI_BT_AUTO_SYNC_PB);
	public static final Uri URI_TRI_BT_AUTO_SYNC_LOG = Settings.Global
			.getUriFor(TRI_BT_AUTO_SYNC_LOG);
	public static final int STATE_ENABLE = 1;
	public static final int STATE_DISENABLE = 0;
	public static final int STATE_ERROR = -1;

	/**
	 * 获取自定义的系统settings值
	 * @param context
	 * @param key
	 * @return
	 */
	public static int getBTSettingsValue(Context context, String key) {

		return Settings.Global.getInt(context.getContentResolver(), key,
				STATE_ERROR);
	}

	/**
	 * 重写自定义的系统Settings值
	 * @param context
	 * @param key
	 * @param value
	 * @return
	 */
	public static boolean writeBTSettingsValue(Context context, String key,
			int value) {

		return Settings.Global.putInt(context.getContentResolver(), key, value);
	}

}
