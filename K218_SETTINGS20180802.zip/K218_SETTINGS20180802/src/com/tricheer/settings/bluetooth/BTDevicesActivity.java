package com.tricheer.settings.bluetooth;

import android.os.Bundle;
import android.widget.Toast;

import com.tricheer.settings.R;
import com.tricheer.settings.BaseSubActivity;

public class BTDevicesActivity extends BaseSubActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bt_device_layout);
		setTitleString("蓝牙设备列表");
		needRefreshIcon(true);
	}

	@Override
	public void onBack() {
		// TODO Auto-generated method stub
		super.onBack();
	}
	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		super.onRefresh();
		Toast.makeText(this, "refresh...", Toast.LENGTH_SHORT).show();
	}
}
