package com.tricheer.settings.bluetooth;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.tricheer.bt.service.device.BTDevice;
import com.tricheer.bt.service.device.BTDeviceCallBack;
import com.tricheer.settings.R;
import com.tricheer.settings.fragment.BaseFragment;
import com.tricheer.settings.util.Logger;

/**
 * 蓝牙设置UI 直接进入使用intent.putExtra("launch","bluetooth")
 * 
 * settings.global.putInt();
 * tri_bt_auto_accept
 * tri_bt_auto_connect
 * tri_bt_auto_sync_pb
 * tri_bt_auto_sync_log
 *
 */
public class BTFragment extends BaseFragment implements OnClickListener {
	private View mView;
	private static String TAG = "BTFragment";
	public static final int INDEX = 3;
	private ImageButton btn_enable, btn_auto_sync_pb, btn_auto_sync_log,
			btn_auto_accept, btn_auto_connect;
	private EditText et_name;
	private TextView connect_info;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		Logger.i(TAG, "onCreateView....");
		mView = inflater.inflate(R.layout.frag_layout_bt, container, false);
		bindView();
//		initEvent();
		return mView;
	}

	private void initEvent() {
		// TODO Auto-generated method stub
		mBtDevice = new BTDevice(getActivity(), new BTDeviceCallBack() {

			@Override
			public void onOneDeviceDiscovered(BluetoothDevice arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onDevicePinChanged(String arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onDeviceNameChanged(String arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onDeviceDiscoveryStarted() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onDeviceDiscoveryCompleted() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onDeviceBondChanged(BluetoothDevice arg0, int arg1) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onBTDeviceEnableChanged(int arg0) {
				// TODO Auto-generated method stub
				Logger.i(TAG, " " + arg0);
				mHandler.sendMessage(mHandler.obtainMessage(
						MSG_ACTION_STATE_CHANGED, arg0, 0));

			}

			@Override
			public void onBindSuccess() {
				// TODO Auto-generated method stub
				mHandler.sendEmptyMessage(MSG_ACTION_BIND_SUCCESS);

			}

			@Override
			public void onConnectionStateChanged(BluetoothDevice arg0,
					int arg1, int arg2) {
				// TODO Auto-generated method stub
				Logger.i(TAG, "onConnectionStateChanged " + arg0.toString()
						+ ";  profile " + arg1 + ";  state " + arg2);
				mHandler.sendMessage(mHandler.obtainMessage(
						MSG_ACTION_CONNECT_CHANGED, arg1, arg2));
			}
		});
		getActivity()
				.getContentResolver()
				.registerContentObserver(
						android.provider.Settings.Global
								.getUriFor(BTSettingsGlobal.TRI_BT_AUTO_ACCEPT),
						false, myObserver);
		getActivity()
				.getContentResolver()
				.registerContentObserver(
						android.provider.Settings.Global
								.getUriFor(BTSettingsGlobal.TRI_BT_AUTO_CONNECT),
						false, myObserver);
		getActivity()
				.getContentResolver()
				.registerContentObserver(
						android.provider.Settings.Global
								.getUriFor(BTSettingsGlobal.TRI_BT_AUTO_SYNC_PB),
						false, myObserver);
		getActivity()
				.getContentResolver()
				.registerContentObserver(
						android.provider.Settings.Global
								.getUriFor(BTSettingsGlobal.TRI_BT_AUTO_SYNC_LOG),
						false, myObserver);

	}

	private MyObserver myObserver;

	private class MyObserver extends ContentObserver {
		private final Handler handler;

		public MyObserver(Handler handler) {
			super(handler);
			// TODO Auto-generated constructor stub
			this.handler = handler;
		}

		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stub
			super.onChange(selfChange, uri);
			Logger.i(TAG, "onChange " + uri);
			handler.sendMessage(handler.obtainMessage(
					MSG_ACTION_SETTINGS_VALUE_CHANGED, uri));

		}
	}

	private void initView() {
		// TODO Auto-generated method stub
		int state = mBtDevice.getState();
		Logger.i(TAG, "initView..." + state);
		if (state == BluetoothAdapter.STATE_ON) {
			if (!btn_enable.isEnabled())
				btn_enable.setEnabled(true);
			btn_enable.setSelected(true);
		} else if (state == BluetoothAdapter.STATE_OFF) {
			if (!btn_enable.isEnabled())
				btn_enable.setEnabled(true);
			btn_enable.setSelected(false);
		} else {
			btn_enable.setEnabled(false);
		}
		et_name.setText(mBtDevice.getLocalBtName());
		btn_auto_accept
				.setSelected(BTSettingsGlobal.getBTSettingsValue(getActivity(),
						BTSettingsGlobal.TRI_BT_AUTO_ACCEPT) == BTSettingsGlobal.STATE_ENABLE);
		btn_auto_connect
				.setSelected(BTSettingsGlobal.getBTSettingsValue(getActivity(),
						BTSettingsGlobal.TRI_BT_AUTO_CONNECT) == BTSettingsGlobal.STATE_ENABLE);
		btn_auto_sync_pb
				.setSelected(BTSettingsGlobal.getBTSettingsValue(getActivity(),
						BTSettingsGlobal.TRI_BT_AUTO_SYNC_PB) == BTSettingsGlobal.STATE_ENABLE);
		btn_auto_sync_log
				.setSelected(BTSettingsGlobal.getBTSettingsValue(getActivity(),
						BTSettingsGlobal.TRI_BT_AUTO_SYNC_LOG) == BTSettingsGlobal.STATE_ENABLE);
		int connect_state = mBtDevice.getConnectState(BTDevice.HEADSET_CLINET);
		refreshConnectView(connect_state);

	}

	private void refreshConnectView(int state) {
		// TODO Auto-generated method stub
		if (connect_info != null) {
			switch (state) {
			case BluetoothProfile.STATE_CONNECTED:
				connect_info.setText(R.string.device_connected_string);
				break;
			case BluetoothProfile.STATE_DISCONNECTED:
				connect_info.setText(R.string.device_disconnected_string);
				break;
			case BluetoothProfile.STATE_DISCONNECTING:
				connect_info.setText(R.string.device_disconnecting_string);
				break;
			case BluetoothProfile.STATE_CONNECTING:
				connect_info.setText(R.string.device_connecting_string);
				break;
			default:
				break;
			}
		}
	}

	private void bindView() {
		// TODO Auto-generated method stub
		btn_enable = (ImageButton) mView.findViewById(R.id.settings_bt_enable);
		btn_auto_sync_pb = (ImageButton) mView
				.findViewById(R.id.settings_bt_auto_sync_pb_btn);
		btn_auto_sync_log = (ImageButton) mView
				.findViewById(R.id.settings_bt_auto_sync_log_btn);
		btn_auto_accept = (ImageButton) mView
				.findViewById(R.id.settings_bt_auto_accept_btn);
		btn_auto_connect = (ImageButton) mView
				.findViewById(R.id.settings_bt_auto_connect_btn);
		et_name = (EditText) mView.findViewById(R.id.settings_bt_name_edit);
		btn_enable.setOnClickListener(this);
		btn_auto_sync_pb.setOnClickListener(this);
		btn_auto_sync_log.setOnClickListener(this);
		btn_auto_accept.setOnClickListener(this);
		btn_auto_connect.setOnClickListener(this);
		btn_auto_connect.setSelected(false);
	}

	@Override
	public void onClick(final View v) {
		// TODO Auto-generated method stub
		Logger.i(TAG, "onclick.....");
		switch (v.getId()) {
		case R.id.settings_bt_enable:
			clickEnableBt();
			break;
		case R.id.settings_bt_auto_accept_btn:
			BTSettingsGlobal
					.writeBTSettingsValue(getActivity(),
							BTSettingsGlobal.TRI_BT_AUTO_ACCEPT,
							v.isSelected() ? 0 : 1);
			v.setEnabled(false);
			break;
		case R.id.settings_bt_auto_connect_btn:
			BTSettingsGlobal.writeBTSettingsValue(getActivity(),
					BTSettingsGlobal.TRI_BT_AUTO_CONNECT, v.isSelected() ? 0
							: 1);
			v.setEnabled(false);
			break;
		case R.id.settings_bt_auto_sync_pb_btn:
			BTSettingsGlobal.writeBTSettingsValue(getActivity(),
					BTSettingsGlobal.TRI_BT_AUTO_SYNC_PB, v.isSelected() ? 0
							: 1);
			v.setEnabled(false);
			break;
		case R.id.settings_bt_auto_sync_log_btn:
			BTSettingsGlobal.writeBTSettingsValue(getActivity(),
					BTSettingsGlobal.TRI_BT_AUTO_SYNC_LOG, v.isSelected() ? 0
							: 1);
			v.setEnabled(false);
			break;
		default:
			break;
		}
	}

	private void clickEnableBt() {
		// TODO Auto-generated method stub
		mBtDevice.enable(!btn_enable.isSelected());
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Logger.i(TAG, "onCreate....");
	}

	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		Logger.i(TAG, "onAttach....");
		myObserver = new MyObserver(mHandler);

	}

	@Override
	public void onDestroyView() {
		// TODO Auto-generated method stub
		mBtDevice.release();
		getActivity().getContentResolver()
				.unregisterContentObserver(myObserver);
		super.onDestroyView();
		Logger.i(TAG, "onDestroyView....");
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

		Logger.i(TAG, "onDestroy....");
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		Logger.i(TAG, "onPause....");
	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		Logger.i(TAG, "onStop....");
	}

	private BTDevice mBtDevice;

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Logger.i(TAG, "onResume....");

	}

	private static final int MSG_ACTION_BOND_STATE_CHANGED = 101;
	private static final int MSG_ACTION_LOCAL_NAME_CHANGED = 105;
	private static final int MSG_ACTION_STATE_CHANGED = 106;
	private static final int MSG_ACTION_BIND_SUCCESS = 107;
	private static final int MSG_ACTION_SETTINGS_VALUE_CHANGED = 108;
	private static final int MSG_ACTION_CONNECT_CHANGED = 109;
	@SuppressLint("HandlerLeak")
	private final Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MSG_ACTION_BOND_STATE_CHANGED:
				// Bundle data = msg.getData();
				// onDeviceBondChanged(
				// (BluetoothDevice) data.getParcelable("device"),
				// data.getInt("state"));
				break;
			case MSG_ACTION_LOCAL_NAME_CHANGED:
				// onDeviceNameChanged(msg.getData().getString("name"));
				break;
			case MSG_ACTION_STATE_CHANGED:
				onBTDeviceEnableChanged(msg.arg1);
				break;
			case MSG_ACTION_BIND_SUCCESS:
				initView();
				break;
			case MSG_ACTION_SETTINGS_VALUE_CHANGED:
				refreshSettingUI((Uri) msg.obj);
				break;
			case MSG_ACTION_CONNECT_CHANGED:
				if (msg.arg1 == BTDevice.HEADSET_CLINET) {
					refreshConnectView(msg.arg2);
				}
				break;
			default:
				break;
			}
		}
	};

	protected void onBTDeviceEnableChanged(int arg1) {
		// TODO Auto-generated method stub
		if (arg1 == BluetoothAdapter.STATE_ON) {
			if (!btn_enable.isEnabled())
				btn_enable.setEnabled(true);
			btn_enable.setSelected(true);

		} else if (arg1 == BluetoothAdapter.STATE_OFF) {
			if (!btn_enable.isEnabled())
				btn_enable.setEnabled(true);
			btn_enable.setSelected(false);

		} else {
			if (btn_enable.isEnabled())
				btn_enable.setEnabled(false);
		}
	}

	protected void refreshSettingUI(Uri obj) {
		// TODO Auto-generated method stub
		if (BTSettingsGlobal.URI_TRI_BT_AUTO_ACCEPT.equals(obj)) {
			if (!btn_auto_accept.isEnabled())
				btn_auto_accept.setEnabled(true);
			btn_auto_accept
					.setSelected(BTSettingsGlobal.getBTSettingsValue(
							getActivity(), BTSettingsGlobal.TRI_BT_AUTO_ACCEPT) == BTSettingsGlobal.STATE_ENABLE);
		} else if (BTSettingsGlobal.URI_TRI_BT_AUTO_CONNECT.equals(obj)) {
			if (!btn_auto_connect.isEnabled())
				btn_auto_connect.setEnabled(true);
			btn_auto_connect
					.setSelected(BTSettingsGlobal
							.getBTSettingsValue(getActivity(),
									BTSettingsGlobal.TRI_BT_AUTO_CONNECT) == BTSettingsGlobal.STATE_ENABLE);
		} else if (BTSettingsGlobal.URI_TRI_BT_AUTO_SYNC_LOG.equals(obj)) {
			if (!btn_auto_sync_log.isEnabled())
				btn_auto_sync_log.setEnabled(true);
			btn_auto_sync_log
					.setSelected(BTSettingsGlobal.getBTSettingsValue(
							getActivity(),
							BTSettingsGlobal.TRI_BT_AUTO_SYNC_LOG) == BTSettingsGlobal.STATE_ENABLE);
		} else if (BTSettingsGlobal.URI_TRI_BT_AUTO_SYNC_PB.equals(obj)) {
			if (!btn_auto_sync_pb.isEnabled())
				btn_auto_sync_pb.setEnabled(true);
			btn_auto_sync_pb
					.setSelected(BTSettingsGlobal
							.getBTSettingsValue(getActivity(),
									BTSettingsGlobal.TRI_BT_AUTO_SYNC_PB) == BTSettingsGlobal.STATE_ENABLE);
		}
	}

}
