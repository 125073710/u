package com.tricheer.settings;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.FormatStrategy;
import com.orhanobut.logger.Logger;
import com.orhanobut.logger.PrettyFormatStrategy;
import com.tricheer.settings.bluetooth.BTFragment;
import com.tricheer.settings.common.CommonFragment;
import com.tricheer.settings.fragment.BaseFragment;
import com.tricheer.settings.fragment.NoScrollViewPager;
import com.tricheer.settings.fragment.VPFragPagerAdapter;
import com.tricheer.settings.sound.SoundFragment;
import com.tricheer.settings.spec.SpecFragment;
import com.tricheer.settings.wifi.WifiFragment;

/**
 * Tricheer settings 主入口 通过添加extra String值, </p> 可以进入不同的设置界面 </p> 如：进入蓝牙设置：
 * Intent intent = new Intent();</p>
 * intent.setAction("android.tricheer.settings");</p>
 * intent.putExtra("launch","bluetooth");</p> startActivity(intent);
 * </p>直接进入wifi：intent.putExtra("launch","wifi")等
 * 
 */
public class MainActivity extends FragmentActivity implements OnClickListener {
	private static String TAG = "MainActivity_Settings";
	private TextView title_tv_common;
	private TextView title_tv_sound;
	private TextView title_tv_wifi;
	private TextView title_tv_bt;
	private TextView title_tv_spec;
	private NoScrollViewPager vpContent;
	private VPFragPagerAdapter mPageAdapter;
	private int mPageIdx = 0;
	private List<BaseFragment> mListContentFrags = new ArrayList<BaseFragment>();
	private List<TextView> mTextViews = new ArrayList<TextView>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_main);
		initView();
		Intent intent = getIntent();
		if (intent != null) {
			dealLaunchIntent(intent);
		}

	}

	private void initView() {
		// TODO Auto-generated method stub
		title_tv_common = (TextView) findViewById(R.id.title_common);
		title_tv_sound = (TextView) findViewById(R.id.title_sound);
		title_tv_wifi = (TextView) findViewById(R.id.title_wifi);
		title_tv_bt = (TextView) findViewById(R.id.title_bt);
		title_tv_spec = (TextView) findViewById(R.id.title_spec);
		title_tv_common.setOnClickListener(this);
		title_tv_sound.setOnClickListener(this);
		title_tv_wifi.setOnClickListener(this);
		title_tv_bt.setOnClickListener(this);
		title_tv_spec.setOnClickListener(this);
		mListContentFrags.add(CommonFragment.INDEX, new CommonFragment());
		mListContentFrags.add(WifiFragment.INDEX, new WifiFragment());
		mListContentFrags.add(SoundFragment.INDEX, new SoundFragment());
		mListContentFrags.add(BTFragment.INDEX, new BTFragment());
		mListContentFrags.add(SpecFragment.INDEX, new SpecFragment());
		mTextViews.add(CommonFragment.INDEX, title_tv_common);
		mTextViews.add(WifiFragment.INDEX, title_tv_wifi);
		mTextViews.add(SoundFragment.INDEX, title_tv_sound);
		mTextViews.add(BTFragment.INDEX, title_tv_bt);
		mTextViews.add(SpecFragment.INDEX, title_tv_spec);
		vpContent = (NoScrollViewPager) findViewById(R.id.vp_content);
		mPageAdapter = new VPFragPagerAdapter(getSupportFragmentManager());
		mPageAdapter.setListFrags(mListContentFrags);
		vpContent.setAdapter(mPageAdapter);
		vpContent.setNoScroll(true);

		// switchPage(WifiFragment.INDEX);
		switchPage(CommonFragment.INDEX);
		FormatStrategy formatStrategy = PrettyFormatStrategy.newBuilder()
		        .tag("K218Setting")//（可选）每个日志的全局标记。 默认PRETTY_LOGGER
		        .build();
		Logger.addLogAdapter(new AndroidLogAdapter(formatStrategy));
	}

	private void switchTitleInfo() {
		// TODO Auto-generated method stub
		for (int i = 0; i < mTextViews.size(); i++) {
			if (i == mPageIdx) {
				mTextViews.get(i).setTextColor(getResources().getColor(R.color.color_white));
			} else {
				mTextViews.get(i).setTextColor(getResources().getColor(R.color.color_white_20));
			}
		}
	}

	private void switchPage(int index) {
		mPageIdx = index;
		switchTitleInfo();
		vpContent.setCurrentItem(mPageIdx, false);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.title_common:
			switchPage(CommonFragment.INDEX);

			break;
		case R.id.title_wifi:
			switchPage(WifiFragment.INDEX);

			break;
		case R.id.title_sound:
			switchPage(SoundFragment.INDEX);
			break;
		case R.id.title_bt:
			switchPage(BTFragment.INDEX);

			break;
		case R.id.title_spec:
			switchPage(SpecFragment.INDEX);
			break;
		default:
			switchPage(CommonFragment.INDEX);
			break;
		}
	}

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		if (intent != null) {
			dealLaunchIntent(intent);
		}

	}

	private void dealLaunchIntent(Intent intent) {
		String info = intent.getStringExtra("launch");
		Logger.i(TAG, "dealLaunchIntent " + info);
		if ("bluetooth".equals(info)) {
			switchPage(BTFragment.INDEX);
		} else if ("common".equals(info)) {
			switchPage(CommonFragment.INDEX);
		} else if ("spec".equals(info)) {
			switchPage(SpecFragment.INDEX);
		} else if ("sound".equals(info)) {
			switchPage(SoundFragment.INDEX);
		} else if ("wifi".equals(info)) {
			switchPage(WifiFragment.INDEX);
		}
	}

}
