package com.tricheer.settings.fragment;

import java.util.List;

import com.tricheer.settings.fragment.BaseFragment;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * 页卡适配器
 * 
 */
public class VPFragPagerAdapter extends FragmentPagerAdapter {
	String TAG = "VPFragPagerAdapter...";
	/**
	 * Fragment List
	 */
	private List<BaseFragment> mListFms;

	public VPFragPagerAdapter(FragmentManager fm) {
		super(fm);
	}

	public void setListFrags(List<BaseFragment> listFms) {
		this.mListFms = listFms;
	}

	@Override
	public Fragment getItem(int position) {
		if (mListFms == null || mListFms.size() == 0) {
			return null;
		}
		return mListFms.get(position);
	}

	@Override
	public int getCount() {
		if (mListFms == null) {
			return 0;
		}

		return mListFms.size();
	}
}
