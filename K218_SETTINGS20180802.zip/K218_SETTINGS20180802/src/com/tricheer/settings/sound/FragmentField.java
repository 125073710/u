package com.tricheer.settings.sound;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.TextView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.R;
import com.tricheer.settings.ui.CoordinateView;

/**
 * Created by yangbofeng on 2018/7/4.
 */

public class FragmentField extends Fragment implements OnClickListener {
	private String TAG = "FragmentField";
	private View view;
	private CoordinateView mCoordinateView;
	private TextView editText1;
	private TextView editText2;
	private int top;
	private int bottom;
	private int left;
	private int right;
	private int x;
	private int y;
	private float baseX;
	private float baseY;
	private int mLocalXY[] = new int[2];
	private Button leftButton, rightButton, forwardButton, backButton, resetButton;

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragmen_field, container, false);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		initView();
	}

	private void initView() {
		// TODO Auto-generated method stub
		mCoordinateView = (CoordinateView) view.findViewById(R.id.coordinateView);
		mCoordinateView.setOnTouchListener(mTouchListener);

		leftButton = (Button) view.findViewById(R.id.left);
		leftButton.setOnClickListener(this);

		rightButton = (Button) view.findViewById(R.id.right);
		rightButton.setOnClickListener(this);

		forwardButton = (Button) view.findViewById(R.id.forward);
		forwardButton.setOnClickListener(this);

		backButton = (Button) view.findViewById(R.id.back);
		backButton.setOnClickListener(this);

		resetButton = (Button) view.findViewById(R.id.reset);
		resetButton.setOnClickListener(this);

		editText1 = (TextView) view.findViewById(R.id.editText1);
		editText2 = (TextView) view.findViewById(R.id.editText2);

		mCoordinateView.post(new Runnable() {
			@Override
			public void run() {
				top = mCoordinateView.getTop();
				bottom = mCoordinateView.getBottom();
				left = mCoordinateView.getLeft();
				right = mCoordinateView.getRight();
				Logger.d("top=" + top + ";bottom=" + bottom + ";left=" + left + ";right=" + right);

				int[] location = new int[2];
				mCoordinateView.getLocationOnScreen(location);
				x = location[0];
				y = location[1];
				baseX = (right - left) / 15;
				Logger.d(TAG, "baseX=" + baseX);
				baseY = (bottom - top) / 15;
				Logger.e("baseY=" + baseY);
				Logger.d("top=" + top + ";left=" + left);
				mCoordinateView.setHLine(0, baseX * 8, right, baseX * 8);
				mCoordinateView.setVLine(baseY * 8, 0, baseY * 8, bottom);
				String x_local = null;// UtilShardPre.getParamsValue(Constant.CAR_SETTINGS_SHARED_PRE,"local_x",
										// getActivity());
				String y_local = null;// UtilShardPre.getParamsValue(Constant.CAR_SETTINGS_SHARED_PRE,"local_y",
										// getActivity());
				Logger.d(x_local + ";" + y_local);
				if (x_local != null && y_local != null) {
					mLocalXY[0] = Integer.parseInt(x_local);
					mLocalXY[1] = Integer.parseInt(y_local);
					mCoordinateView.setInvalidate(baseX * ((Integer.parseInt(x_local) + 1)),
							baseY * ((Integer.parseInt(y_local)) + 1));
				} else {
					mLocalXY[0] = 7;
					mLocalXY[1] = 7;
					mCoordinateView.setInvalidate(baseX * 8, baseY * 8);
					editText1.setText("X=" + (mLocalXY[0] - 7));
					editText2.setText("Y=" + (7 - mLocalXY[1]));
					/*
					 * UtilShardPre.setParams(Constant.CAR_SETTINGS_SHARED_PRE,
					 * "local_x", "7", getActivity());
					 * UtilShardPre.setParams(Constant
					 * .CAR_SETTINGS_SHARED_PRE,"local_y", "7", getActivity());
					 */
				}
			}
		});
	}

	private OnTouchListener mTouchListener = new OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			float x = event.getX();
			float y = event.getY();
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				mCoordinateView.setInvalidate(getXY(x, y)[0], getXY(x, y)[1]);
				break;
			case MotionEvent.ACTION_MOVE:
				mCoordinateView.setInvalidate(getXY(x, y)[0], getXY(x, y)[1]);
				break;
			case MotionEvent.ACTION_UP:
				mCoordinateView.setInvalidate(getXY(x, y)[0], getXY(x, y)[1]);
				break;
			}
			Logger.e("X=" + mLocalXY[0] + "----" + "Y =" + mLocalXY[1]);
			setValueToTarget();
			return true;
		}
	};

	private float[] getXY(float x, float y) {
		float[] xy = new float[2];
		if (x < (baseX * 1)) {
			xy[0] = baseX * 1;
			mLocalXY[0] = 0;
		} else if ((baseX * 1) < x && x < (baseX * 2)) {
			xy[0] = baseX * 2;
			mLocalXY[0] = 1;
		} else if ((baseX * 2) < x && x < (baseX * 3)) {
			xy[0] = baseX * 3;
			mLocalXY[0] = 2;
		} else if ((baseX * 3) < x && x < (baseX * 4)) {
			xy[0] = baseX * 4;
			mLocalXY[0] = 3;
		} else if ((baseX * 4) < x && x < (baseX * 5)) {
			xy[0] = baseX * 5;
			mLocalXY[0] = 4;
		} else if ((baseX * 5) < x && x < (baseX * 6)) {
			xy[0] = baseX * 6;
			mLocalXY[0] = 5;
		} else if ((baseX * 6) < x && x < (baseX * 7)) {
			xy[0] = baseX * 7;
			mLocalXY[0] = 6;
		} else if ((baseX * 7) < x && x < (baseX * 8)) {
			xy[0] = baseX * 8;
			mLocalXY[0] = 7;
		} else if ((baseX * 8) < x && x < (baseX * 9)) {
			xy[0] = baseX * 9;
			mLocalXY[0] = 8;
		} else if ((baseX * 9) < x && x < (baseX * 10)) {
			xy[0] = baseX * 10;
			mLocalXY[0] = 9;
		} else if ((baseX * 10) < x && x < (baseX * 11)) {
			xy[0] = baseX * 11;
			mLocalXY[0] = 10;
		} else if ((baseX * 11) < x && x < (baseX * 12)) {
			xy[0] = baseX * 12;
			mLocalXY[0] = 11;
		} else if ((baseX * 12) < x && x < (baseX * 13)) {
			xy[0] = baseX * 13;
			mLocalXY[0] = 12;
		} else if ((baseX * 13) < x && x < (baseX * 14)) {
			xy[0] = baseX * 14;
			mLocalXY[0] = 13;
		} else if ((baseX * 14) < x && x < (baseX * 15)) {
			xy[0] = baseX * 15;
			mLocalXY[0] = 14;
		} else if ((baseX * 15) < x) {
			xy[0] = baseX * 15;
			mLocalXY[0] = 14;
		}
		if (y < (baseY * 1)) {
			xy[1] = baseY * 1;
			mLocalXY[1] = 0;
		} else if ((baseY * 1) < y && y < (baseY * 2)) {
			xy[1] = baseY * 2;
			mLocalXY[1] = 1;
		} else if ((baseY * 2) < y && y < (baseY * 3)) {
			xy[1] = baseY * 3;
			mLocalXY[1] = 2;
		} else if ((baseY * 3) < y && y < (baseY * 4)) {
			xy[1] = baseY * 4;
			mLocalXY[1] = 3;
		} else if ((baseY * 4) < y && y < (baseY * 5)) {
			xy[1] = baseY * 5;
			mLocalXY[1] = 4;
		} else if ((baseY * 5) < y && y < (baseY * 6)) {
			xy[1] = baseY * 6;
			mLocalXY[1] = 5;
		} else if ((baseY * 6) < y && y < (baseY * 7)) {
			xy[1] = baseY * 7;
			mLocalXY[1] = 6;
		} else if ((baseY * 7) < y && y < (baseY * 8)) {
			xy[1] = baseY * 8;
			mLocalXY[1] = 7;
		} else if ((baseY * 8) < y && y < (baseY * 9)) {
			xy[1] = baseY * 9;
			mLocalXY[1] = 8;
		} else if ((baseY * 9) < y && y < (baseY * 10)) {
			xy[1] = baseY * 10;
			mLocalXY[1] = 9;
		} else if ((baseY * 10) < y && y < (baseY * 11)) {
			xy[1] = baseY * 11;
			mLocalXY[1] = 10;
		} else if ((baseY * 11) < y && y < (baseY * 12)) {
			xy[1] = baseY * 12;
			mLocalXY[1] = 11;
		} else if ((baseY * 12) < y && y < (baseY * 13)) {
			xy[1] = baseY * 13;
			mLocalXY[1] = 12;
		} else if ((baseY * 13) < y && y < (baseY * 14)) {
			xy[1] = baseY * 14;
			mLocalXY[1] = 13;
		} else if ((baseY * 14) < y && y < (baseY * 15)) {
			xy[1] = baseY * 15;
			mLocalXY[1] = 14;
		} else if ((baseY * 15) < y) {
			xy[1] = baseY * 15;
			mLocalXY[1] = 14;
		}
		// UtilShardPre.setParams(Constant.CAR_SETTINGS_SHARED_PRE,"local_x",
		// mLocalXY[0]+"", getActivity());
		// UtilShardPre.setParams(Constant.CAR_SETTINGS_SHARED_PRE,"local_y",
		// mLocalXY[1]+"", getActivity());
		return xy;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v == leftButton) { // 左
			if (mLocalXY[0] > 0) {
				mLocalXY[0] = mLocalXY[0] - 1;
			}

		} else if (v == rightButton) { // 右
			if (mLocalXY[0] < 14) {
				mLocalXY[0] = mLocalXY[0] + 1;
			}
		} else if (v == forwardButton) { // 前
			if (mLocalXY[1] > 0) {
				mLocalXY[1] = mLocalXY[1] - 1;
			}

		} else if (v == backButton) { // 后
			if (mLocalXY[1] < 14) {
				mLocalXY[1] = mLocalXY[1] + 1;
			}
		} else if (v == resetButton) {
			mLocalXY[0] = 7;
			mLocalXY[1] = 7;
		}
		Logger.e("X=" + mLocalXY[0] + "----" + "Y =" + mLocalXY[1]);

		mCoordinateView.setInvalidate(baseX * (mLocalXY[0] + 1), baseY * (mLocalXY[1] + 1));
		// UtilShardPre.setParams(Constant.CAR_SETTINGS_SHARED_PRE,"local_x",
		// mLocalXY[0]+"", getActivity());
		// UtilShardPre.setParams(Constant.CAR_SETTINGS_SHARED_PRE,"local_y",
		// mLocalXY[1]+"", getActivity());
		setValueToTarget();
	}

	private void setValueToTarget() {

		editText1.setText("X=" + (mLocalXY[0] - 7));
		editText2.setText("Y=" + (7 - mLocalXY[1]));
		/*
		 * String x_local =
		 * UtilShardPre.getParamsValue(Constant.CAR_SETTINGS_SHARED_PRE
		 * ,"local_x", getActivity()); String y_local =
		 * UtilShardPre.getParamsValue
		 * (Constant.CAR_SETTINGS_SHARED_PRE,"local_y", getActivity()); int lr =
		 * Integer.valueOf(x_local); int fb = 14-(Integer.valueOf(y_local)); try
		 * { mService.commonCmd(0x97, new byte[]{(byte) lr});
		 * mService.commonCmd(0x96, new byte[]{(byte) fb}); } catch
		 * (RemoteException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

	}
}
