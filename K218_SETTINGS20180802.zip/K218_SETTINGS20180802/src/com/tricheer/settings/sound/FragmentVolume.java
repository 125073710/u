package com.tricheer.settings.sound;

import java.text.DecimalFormat;

import android.app.Fragment;
import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.R;
import com.tricheer.settings.ui.CallSeekBar;
import com.tricheer.settings.ui.mSeekBar;

/**
 * Created by yangbofeng on 2018/7/4.
 */

public class FragmentVolume extends Fragment {
	private View view;
	private mSeekBar seekBar_medial, seekBar_map;
	private CallSeekBar seekBar_call;
	private ImageButton imgbt_key_volice;
	private boolean isopen = true;
	private AudioManager audioManager;
	private double media;

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_volume, container, false);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		audioManager = (AudioManager) getActivity().getSystemService(Context.AUDIO_SERVICE);
		initView();
		initData();
	}

	private void initData() {
		// TODO Auto-generated method stub
		// 初始化按键音状态
		int i = Settings.System.getInt(getActivity().getContentResolver(), Settings.System.SOUND_EFFECTS_ENABLED, 0);
		if (i == 1) {
			imgbt_key_volice.setImageDrawable(getActivity().getResources().getDrawable(R.drawable.btn_open));
		} else {
			imgbt_key_volice.setImageDrawable(getActivity().getResources().getDrawable(R.drawable.btn_close));
		}
		int mediamax = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
		Logger.e("媒体音最大值=" + mediamax);
		// 获取媒体音 最大值
		int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
		seekBar_medial.SetValue(currentVolume + "");
		seekBar_medial.setProgress(currentVolume);
		// 
	
		// 通话音
		int currentCallVolume = audioManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL);
		seekBar_call.SetValue((currentCallVolume + 5) + "");
		seekBar_call.setProgress(currentCallVolume + 5);
		// 导航音
	}

	private void initView() {
		// TODO Auto-generated method stub
		seekBar_medial = (mSeekBar) view.findViewById(R.id.seekBar_medial);
		seekBar_call = (CallSeekBar) view.findViewById(R.id.seekBar_call);
		seekBar_map = (mSeekBar) view.findViewById(R.id.seekBar_map);
		imgbt_key_volice = (ImageButton) view.findViewById(R.id.imgbt_key_volice);
		seekBar_medial.setOnSeekBarChangeListener(mSeekChange);
		seekBar_call.setOnSeekBarChangeListener(mSeekChangeCall);
		seekBar_map.setOnSeekBarChangeListener(mSeekChangeMap);

		imgbt_key_volice.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (isopen) {
					imgbt_key_volice.setImageDrawable(getActivity().getResources().getDrawable(R.drawable.btn_open));
					Settings.System
							.putInt(getActivity().getContentResolver(), Settings.System.SOUND_EFFECTS_ENABLED, 1);
					isopen = false;
				} else {
					imgbt_key_volice.setImageDrawable(getActivity().getResources().getDrawable(R.drawable.btn_close));
					Settings.System
							.putInt(getActivity().getContentResolver(), Settings.System.SOUND_EFFECTS_ENABLED, 0);
					isopen = true;
				}
			}
		});
	}

	/**
	 * 媒体音量
	 */
	private OnSeekBarChangeListener mSeekChange = new OnSeekBarChangeListener() {
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		}

		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {
		}

		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			int progress = (seekBar.getProgress());

			Logger.e((progress) + "");
			seekBar_medial.SetValue((progress) + "");
		}
	};
	/**
	 * 通话音
	 */
	private OnSeekBarChangeListener mSeekChangeCall = new OnSeekBarChangeListener() {
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		}

		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {
		}

		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			int progress = seekBar.getProgress();
			Logger.e(progress + "");
			seekBar_call.SetValue((progress + 5) + "");
	//		audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, progress + 5, AudioManager.FLAG_PLAY_SOUND);
		}
	};
	private OnSeekBarChangeListener mSeekChangeMap = new OnSeekBarChangeListener() {
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		}

		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {
		}

		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			int progress = seekBar.getProgress();
			Logger.e(progress + "");
			seekBar_map.SetValue(progress + "");
		}
	};
}
