package com.tricheer.settings.sound;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.tricheer.settings.R;
import com.tricheer.settings.fragment.BaseFragment;

/**
 * 声音设置UI 直接进入使用intent.putExtra("launch","sound")
 * 
 */
@SuppressLint("ResourceAsColor")
public class SoundFragment extends BaseFragment implements OnClickListener {
	private View mView;
	private TextView bt_voiume, bt_junhengqi, voice_field;
	private static String TAG = "SoundFragment";
	public static final int INDEX = 2;
	private FragmentVolume fragment;
	private FragmentEqualizer fragment2;
	private FragmentField fragment3;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		mView = inflater.inflate(R.layout.frag_layout_sound, container, false);
		FragmentVolume fragment = new FragmentVolume();
		FragmentTransaction transaction2 = getActivity().getFragmentManager().beginTransaction();
		transaction2.add(R.id.fragment1, fragment);
		transaction2.commit();

		initView();

		return mView;
	}

	private void initView() {
		// TODO Auto-generated method stub
		bt_voiume = (TextView) mView.findViewById(R.id.bt_voiume);
		bt_junhengqi = (TextView) mView.findViewById(R.id.bt_junhengqi);
		voice_field = (TextView) mView.findViewById(R.id.voice_field);
		bt_voiume.setOnClickListener(this);
		bt_junhengqi.setOnClickListener(this);
		voice_field.setOnClickListener(this);
		bt_voiume.setBackground(getActivity().getDrawable(R.drawable.title_c));
	}

	@SuppressLint("ResourceAsColor")
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bt_voiume:
			fragment = new FragmentVolume();
			FragmentTransaction transaction1 = getActivity().getFragmentManager().beginTransaction();
			transaction1.replace(R.id.fragment1, fragment);
			hideFragment(transaction1);
			transaction1.show(fragment);
			transaction1.commit();
			bt_voiume.setBackground(getActivity().getDrawable(R.drawable.title_c));
			bt_junhengqi.setBackgroundColor(R.color.color_transparent);
			voice_field.setBackgroundColor(R.color.color_transparent);
			break;
		case R.id.bt_junhengqi:
			fragment2 = new FragmentEqualizer();
			FragmentTransaction transaction2 = getActivity().getFragmentManager().beginTransaction();
			transaction2.replace(R.id.fragment1, fragment2);
			hideFragment(transaction2);
			transaction2.show(fragment2);
			transaction2.commit();
			bt_junhengqi.setBackground(getActivity().getDrawable(R.drawable.title_c));
			bt_voiume.setBackgroundColor(R.color.color_transparent);
			voice_field.setBackgroundColor(R.color.color_transparent);
			break;
		case R.id.voice_field:
			FragmentField fragment3 = new FragmentField();
			FragmentTransaction transaction3 = getActivity().getFragmentManager().beginTransaction();
			transaction3.replace(R.id.fragment1, fragment3);
			hideFragment(transaction3);
			transaction3.show(fragment3);
			transaction3.commit();
			voice_field.setBackground(getActivity().getDrawable(R.drawable.title_c));
			bt_voiume.setBackgroundColor(R.color.color_transparent);
			bt_junhengqi.setBackgroundColor(R.color.color_transparent);
			break;

		}
	}

	// 隐藏所有的fragment
	private void hideFragment(FragmentTransaction transaction) {
		if (fragment != null) {
			transaction.hide(fragment);
		}
		if (fragment2 != null) {
			transaction.hide(fragment2);
		}
		if (fragment3 != null) {
			transaction.hide(fragment3);
		}
	}
}
