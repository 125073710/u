package com.tricheer.settings.common.date;

import java.util.Calendar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;
import com.tricheer.settings.util.UtilSetting;

/**
 * 时间与日期设置
 * 
 * @author yangbofeng 设置自动时间同步 0关闭，1开启 auto_time
 */
public class DateAndTiemActivity extends BaseSubActivity implements OnClickListener {
	private RelativeLayout rl_set_time, rl_set_date;
	private ImageButton imgbt_auto_time_date;
	boolean isbtopen = false;
	private static final String AUTO_TIEM = "auto_time";
	private Context mContext;
	private TextView tv_time, tv_date;
	private Calendar mCalendar;
	private int year;
	private int month;
	private int day;
	private int hours;
	private int minutes;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setTitleString(getResources().getString(R.string.date_and_time_set));
		setContentView(R.layout.activity_date_time);
		mContext = this;
		mCalendar = Calendar.getInstance();
		initView();
		initDate();
	}

	private void initDate() {
		// TODO Auto-generated method stub
		int value = UtilSetting.getdata(mContext, "auto_time");
		if (0 == value) {
			imgbt_auto_time_date.setImageDrawable(getDrawable(R.drawable.testoff));
			rl_set_time.setEnabled(false);
			rl_set_date.setEnabled(false);
			isbtopen = false;
		} else {
			imgbt_auto_time_date.setImageDrawable(getDrawable(R.drawable.teston));
			rl_set_time.setEnabled(true);
			rl_set_date.setEnabled(true);
			isbtopen = true;
		}
		if (mCalendar == null) {
			mCalendar = Calendar.getInstance();
		}
		year = mCalendar.get(Calendar.YEAR); // 获取当前年份
		month = mCalendar.get(Calendar.MONTH) + 1;// 获取当前月份
		day = mCalendar.get(Calendar.DAY_OF_MONTH);// 获取当日期
		hours = mCalendar.get(Calendar.HOUR_OF_DAY);// 小时
		minutes = mCalendar.get(Calendar.MINUTE); // 分钟
		tv_time.setText(hours + ":" + minutes);
		tv_date.setText(year + "/" + month + "/" + day);
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Logger.e("onResume");

	}

	private void initView() {
		// TODO Auto-generated method stub
		imgbt_auto_time_date = (ImageButton) findViewById(R.id.imgbt_auto_time_date);
		imgbt_auto_time_date.setOnClickListener(this);
		rl_set_time = (RelativeLayout) findViewById(R.id.rl_set_time);
		rl_set_date = (RelativeLayout) findViewById(R.id.rl_set_date);
		rl_set_time.setOnClickListener(this);
		rl_set_date.setOnClickListener(this);

		tv_time = (TextView) findViewById(R.id.tv_time);
		tv_date = (TextView) findViewById(R.id.tv_date);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		switch (v.getId()) {
		case R.id.imgbt_auto_time_date:
			if (isbtopen) {
				UtilSetting.setdata(mContext, "auto_time", 0);
				imgbt_auto_time_date.setImageDrawable(getDrawable(R.drawable.testoff));
				rl_set_time.setEnabled(false);
				rl_set_date.setEnabled(false);
				isbtopen = false;
			} else if (!isbtopen) {
				UtilSetting.setdata(mContext, "auto_time", 1);
				imgbt_auto_time_date.setImageDrawable(getDrawable(R.drawable.teston));
				rl_set_time.setEnabled(true);
				rl_set_date.setEnabled(true);
				isbtopen = true;
			}
			int value = UtilSetting.getdata(mContext, "auto_time");
			Logger.e(" 0 is close ; 1 is open; value= " + value);
			break;
		case R.id.rl_set_time:
			startActivity(DateAndTimeSetTimeActivity.class, 1);
			break;
		case R.id.rl_set_date:
			startActivity(DateAndTimeSetDateActivity.class, 2);
			break;

		}

	}

	public void startActivity(Class class1, int requestCode) {
		Intent intent = new Intent(this, class1);
		startActivityForResult(intent, requestCode);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		Logger.e(requestCode + "");
		if (1 == requestCode) {
			Logger.e(data.getStringExtra("time")+"");
			tv_time.setText(data.getStringExtra("time")+"");
		} else {
			Logger.e(data.getStringExtra("date")+"");
			tv_date.setText(data.getStringExtra("date")+"");
		}

	}
}
