package com.tricheer.settings.common.date;

import java.util.Calendar;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;

/**
 * 设置日期
 * 
 * @author yangbofeng
 * 
 */
public class DateAndTimeSetDateActivity extends BaseSubActivity implements OnClickListener {
	private Button activity_refresh, bt_year, bt_month, bt_day, bt_year_down, bt_month_down, bt_day_down;
	private TextView tv_year, tv_month, tv_day;
	private int year = 1947;
	private int month = 01;
	private int day = 01;
	private Calendar mCalendar;

	/**
	 * 年份 最小1970年0101 最大无限大
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setTitleString(getResources().getString(R.string.date_and_time_set_date));
		setContentView(R.layout.activity_date_time_set_date);
		mCalendar = Calendar.getInstance();
		year = mCalendar.get(Calendar.YEAR); // 获取当前年份
		month = mCalendar.get(Calendar.MONTH) + 1;// 获取当前月份
		day = mCalendar.get(Calendar.DAY_OF_MONTH);// 获取当日期
		initView();

	}

	private void initView() {
		// TODO Auto-generated method stub
		activity_refresh = (Button) findViewById(R.id.activity_refresh);
		activity_refresh.setVisibility(View.VISIBLE);
		activity_refresh.setBackgroundDrawable(getResources().getDrawable(R.drawable.x));
		bt_year = (Button) findViewById(R.id.bt_year);
		bt_month = (Button) findViewById(R.id.bt_month);
		bt_day = (Button) findViewById(R.id.bt_day);
		bt_year_down = (Button) findViewById(R.id.bt_year_down);
		bt_month_down = (Button) findViewById(R.id.bt_month_down);
		bt_day_down = (Button) findViewById(R.id.bt_day_down);

		tv_year = (TextView) findViewById(R.id.tv_year);
		tv_month = (TextView) findViewById(R.id.tv_month);
		tv_day = (TextView) findViewById(R.id.tv_day);

		bt_year.setOnClickListener(this);
		bt_month.setOnClickListener(this);
		bt_day.setOnClickListener(this);
		bt_year_down.setOnClickListener(this);
		bt_month_down.setOnClickListener(this);
		bt_day_down.setOnClickListener(this);

		tv_year.setText(year + "");
		tv_month.setText(getStringTimes(month));
		tv_day.setText(getStringTimes(day));

	}

	/**
	 * 获取当年当月天数
	 * 
	 * @param year
	 * @param month
	 * @return
	 */
	public int getMonthDay(int year, int month) {
		mCalendar.set(year, month, 0); // 输入类型为int类型
		int dayOfMonth = mCalendar.get(Calendar.DAY_OF_MONTH);
		Logger.e(year + "年" + month + "月有" + dayOfMonth + "天");
		return dayOfMonth;
	}

	/**
	 * 格式化 00
	 * 
	 * @param 日期
	 * @return
	 */
	public String getStringTimes(int time) {
		String times = String.format("%02d", time);
		return times;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bt_year:
			if (year <= 1970) {
				year = 1970;
			} else {
				year -= 1;
			}
			tv_year.setText(year + "");
			setSysDate(year, month, day);
			break;
		case R.id.bt_month:
			if (month <= 1) {
				month = 12;
			} else {
				month -= 1;
			}
			Logger.e("month=" + month);
			tv_month.setText(getStringTimes(month));
			setSysDate(year, month, day);
			break;
		case R.id.bt_day:
			if (day <= 1) {
				day = getMonthDay(year, month);
			} else {
				day -= 1;
			}
			tv_day.setText(getStringTimes(day));
			setSysDate(year, month, day);
			break;
		case R.id.bt_year_down:
			year += 1;
			tv_year.setText(year + "");
			setSysDate(year, month, day);
			break;
		case R.id.bt_month_down:
			if (month >= 11) {
				month = 1;
			} else {
				month += 1;
			}
			Logger.e("month=" + month);
			tv_month.setText(getStringTimes(month));
			setSysDate(year, month - 1, day);
			break;
		case R.id.bt_day_down:
			if (day >= getMonthDay(year, month)) {
				day = 1;
			} else {
				day += 1;
			}
			tv_day.setText(getStringTimes(day));
			setSysDate(year, month, day);
			break;
		case R.id.activity_refresh:
			finish();
			break;
		}

		Logger.e(year + "/" + mCalendar.get(Calendar.MONTH) + 1 + "/" + mCalendar.get(Calendar.DAY_OF_MONTH));
	}

	public void setSysDate(int year, int month, int day) {
		Calendar c = Calendar.getInstance();
		c.set(Calendar.YEAR, year);
		c.set(Calendar.MONTH, month);
		c.set(Calendar.DAY_OF_MONTH, day);
		long when = c.getTimeInMillis();
		if (when / 1000 < Integer.MAX_VALUE) {
			((AlarmManager) getSystemService(Context.ALARM_SERVICE)).setTime(when);
		}
	}

	@Override
	public void finish() {
		// TODO Auto-generated method stub
		Intent intent1 = new Intent();
		intent1.putExtra("date", year + "/" + month + "/" + day);
		setResult(2, intent1);
		super.finish();

	}

}
