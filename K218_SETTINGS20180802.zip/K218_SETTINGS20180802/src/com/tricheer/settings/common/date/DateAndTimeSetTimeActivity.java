package com.tricheer.settings.common.date;

import java.util.Calendar;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;

/**
 * 设置时间
 * 
 * @author yangbofeng
 * 
 */
public class DateAndTimeSetTimeActivity extends BaseSubActivity implements OnClickListener {
	private Button activity_refresh, bt_hour, bt_minutes, bt_seconds, bt_hour_down, bt_minutes_down, bt_seconds_down;
	private TextView tv_hour, tv_minutes, tv_seconds;
	private Context mContext;
	private int hours = 0;
	private int minutes = 0;
	private int secondes = 0;
	private Calendar calendar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		/*
		 * requestWindowFeature(Window.FEATURE_NO_TITLE);
		 * getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
		 * WindowManager.LayoutParams.FLAG_FULLSCREEN);
		 */
		super.onCreate(savedInstanceState);
		setTitleString(getResources().getString(R.string.date_and_time_set_time));
		setContentView(R.layout.activity_data_time_set_time);
		mContext = this;
		calendar = Calendar.getInstance();
		hours = calendar.get(Calendar.HOUR_OF_DAY);// 小时
		minutes = calendar.get(Calendar.MINUTE); // 分钟
		secondes = calendar.get(Calendar.SECOND); // 秒
		initView();
		tv_hour.setText(getStringTimes(hours));
		tv_minutes.setText(getStringTimes(minutes));
		tv_seconds.setText(getStringTimes(secondes));
	}

	private void initView() {
		// TODO Auto-generated method stub
		activity_refresh = (Button) findViewById(R.id.activity_refresh);
		bt_hour = (Button) findViewById(R.id.bt_hour);
		bt_minutes = (Button) findViewById(R.id.bt_minutes);
		bt_seconds = (Button) findViewById(R.id.bt_seconds);
		bt_hour_down = (Button) findViewById(R.id.bt_hour_down);
		bt_minutes_down = (Button) findViewById(R.id.bt_minutes_down);
		bt_seconds_down = (Button) findViewById(R.id.bt_seconds_down);
		tv_hour = (TextView) findViewById(R.id.tv_hour);
		tv_minutes = (TextView) findViewById(R.id.tv_minutes);
		tv_seconds = (TextView) findViewById(R.id.tv_seconds);
		activity_refresh.setVisibility(View.VISIBLE);
		activity_refresh.setBackgroundDrawable(getResources().getDrawable(R.drawable.x));
		bt_hour.setOnClickListener(this);
		bt_minutes.setOnClickListener(this);
		bt_seconds.setOnClickListener(this);
		bt_hour_down.setOnClickListener(this);
		bt_minutes_down.setOnClickListener(this);
		bt_seconds_down.setOnClickListener(this);
		activity_refresh.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.bt_hour:
			if (hours <= 0) {
				hours = 23;
			} else {
				hours -= 1;
			}
			setSysTime(hours, minutes, secondes);
			tv_hour.setText(getStringTimes(hours));
			break;
		case R.id.bt_minutes:
			if (minutes <= 0) {
				minutes = 59;
			} else {
				minutes -= 1;
			}
			setSysTime(hours, minutes, secondes);
			tv_minutes.setText(getStringTimes(minutes));
			break;
		case R.id.bt_seconds:
			if (secondes <= 0) {
				secondes = 59;
			} else {
				secondes -= 1;
			}
			setSysTime(hours, minutes, secondes);
			tv_seconds.setText(getStringTimes(secondes));
			break;
		case R.id.bt_hour_down:
			if (hours >= 23) {
				hours = 0;
			} else {
				hours += 1;
			}
			setSysTime(hours, minutes, secondes);
			tv_hour.setText(getStringTimes(hours));
			break;
		case R.id.bt_minutes_down:
			if (minutes >= 59) {
				minutes = 0;
			} else {
				minutes += 1;
			}
			setSysTime(hours, minutes, secondes);
			tv_minutes.setText(getStringTimes(minutes));
			break;
		case R.id.bt_seconds_down:
			if (secondes >= 59) {
				secondes = 0;
			} else {
				secondes += 1;
			}
			setSysTime(hours, minutes, secondes);
			tv_seconds.setText(getStringTimes(secondes));
			break;
		case R.id.activity_refresh:
			finish();
			break;
		}

	}

	/**
	 * 设置系统时间
	 * 
	 * @param hour
	 * @param minute
	 */
	public void setSysTime(int hour, int minute, int second) {
		Calendar c = Calendar.getInstance();
		c.set(Calendar.HOUR_OF_DAY, hour);
		c.set(Calendar.MINUTE, minute);
		c.set(Calendar.SECOND, second);
		c.set(Calendar.MILLISECOND, 0);
		long when = c.getTimeInMillis();
		if (when / 1000 < Integer.MAX_VALUE) {
			((AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE)).setTime(when);
		}
	}

	public String getStringTimes(int time) {
		String times = String.format("%02d", time);
		return times;
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

	}

	@Override
	public void finish() {
		// TODO Auto-generated method stub
		Intent intent1 = new Intent();
		intent1.putExtra("time", hours + ":" + minutes);
		setResult(1, intent1);
		super.finish();

	}

}
