package com.tricheer.settings.common;

public class RebootActivity {

}
