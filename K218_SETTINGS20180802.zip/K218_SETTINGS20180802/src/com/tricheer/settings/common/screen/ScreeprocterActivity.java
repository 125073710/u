package com.tricheer.settings.common.screen;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;
import com.tricheer.settings.View.MyDialog;

/**
 * 屏幕保护
 * 
 * @author yangbofeng
 * 
 */
public class ScreeprocterActivity extends BaseSubActivity {

	private RadioGroup radio_group;
	private RadioButton radio_bt_off, radio_bt_15, radio_bt_30, radio_bt_60, radio_bt_120;
	private TextView tv_text;
	private Context mContext;
	private MyDialog dialog;
	private int tag = 0; // 点击后的值
	private int value = 0;// 获取到系统设置值

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_scree_procter);
		setTitleString(getResources().getString(R.string.common_srcee_protect));
		mContext = this;
		initView();
		initData();
	}

	private void initView() {
		// TODO Auto-generated method stub
		radio_group = (RadioGroup) findViewById(R.id.radio_group);
		radio_bt_off = (RadioButton) findViewById(R.id.radio_bt_off);
		radio_bt_15 = (RadioButton) findViewById(R.id.radio_bt_15);
		radio_bt_30 = (RadioButton) findViewById(R.id.radio_bt_30);
		radio_bt_60 = (RadioButton) findViewById(R.id.radio_bt_60);
		radio_bt_120 = (RadioButton) findViewById(R.id.radio_bt_120);
		tv_text = (TextView) findViewById(R.id.tv_text);
		radio_group.setOnCheckedChangeListener(listener);

	}

	private void initData() {
		// TODO Auto-generated method stub
		// value = UtilSetting.getdata(mContext, "");
		if (value == 0) {
			radio_bt_off.setChecked(true);
		}
		switch (value) {
		case 0:
			radio_bt_off.setChecked(true);
			break;
		case 15:
			radio_bt_15.setChecked(true);
			break;
		case 30:
			radio_bt_30.setChecked(true);
			break;
		case 60:
			radio_bt_60.setChecked(true);
			break;
		case 120:
			radio_bt_120.setChecked(true);
			break;
		}

	}

	OnCheckedChangeListener listener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			// TODO Auto-generated method stub
			switch (checkedId) {
			case R.id.radio_bt_off:
				Logger.e("off");
				tag = 0;
				tv_text.setText(R.string.time_procter_0);
				break;
			case R.id.radio_bt_15:
				Logger.e("15");
				tag = 15;
				tv_text.setText(R.string.time_procter_15);
				break;
			case R.id.radio_bt_30:
				Logger.e("30");
				tag = 30;
				tv_text.setText(R.string.time_procter_30);
				break;
			case R.id.radio_bt_60:
				Logger.e("60");
				tag = 60;
				tv_text.setText(R.string.time_procter_60);
				break;
			case R.id.radio_bt_120:
				Logger.e("120");
				tag = 120;
				tv_text.setText(R.string.time_procter_120);
				break;
			default:
				break;
			}
		}
	};

	public void onBack() {
		Logger.e("value= " + value + "--tag= " + tag);
		if (value == tag) {
			finish();
		} else {
			showDialog();
		}
	}

	/**
	 * 显示提示框
	 */

	private void showDialog() {
		// TODO Auto-generated method stub

		dialog = new MyDialog(this);
		View view = LayoutInflater.from(this).inflate(R.layout.dialog_common, null);
		dialog.setLayoutView(view);
		Window window = dialog.getWindow();
		final WindowManager.LayoutParams p = window.getAttributes();
		p.gravity = Gravity.CENTER;
		p.width = 500;
		p.height = 300;
		window.setAttributes(p);
		window.setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
				WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();

		TextView tv_body = (TextView) view.findViewById(R.id.tv_body);
		TextView tv_yes = (TextView) view.findViewById(R.id.tv_yes);
		TextView tv_no = (TextView) view.findViewById(R.id.tv_no);
		tv_body.setText(R.string.scree_procter_body);
		tv_yes.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

			}
		});
		tv_no.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
				finish();
			}
		});
	};
}
