package com.tricheer.settings.common.screen;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;
import com.tricheer.settings.ui.mSeekBar;
import com.tricheer.settings.util.UtilSetting;

/**
 * 屏幕显示设置
 * 
 * @author yangbofeng
 * 
 */
public class ScreeShowSetActivity extends BaseSubActivity implements OnClickListener {

	private Context mContext;
	private mSeekBar mseekBar;
	private ImageButton imgbt_auto_scree, imgbt_scree_procter, imgbt_wallpaper, imgbt_theme;
	private int size = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activtity_scree_showe);
		mContext = getApplicationContext();
		initView();

	}

	private void initView() {
		// TODO Auto-generated method stub
		setTitleString(getResources().getString(R.string.common_show_setting));
		mseekBar = (mSeekBar) findViewById(R.id.seekBar);
		mseekBar.setOnSeekBarChangeListener(mSeekChange);
		imgbt_auto_scree = (ImageButton) findViewById(R.id.imgbt_auto_scree);
		imgbt_scree_procter = (ImageButton) findViewById(R.id.imgbt_scree_procter);
		imgbt_wallpaper = (ImageButton) findViewById(R.id.imgbt_wallpaper);
		imgbt_theme = (ImageButton) findViewById(R.id.imgbt_theme);
		imgbt_auto_scree.setOnClickListener(this);
		imgbt_scree_procter.setOnClickListener(this);
		imgbt_wallpaper.setOnClickListener(this);
		imgbt_theme.setOnClickListener(this);
		size = getBrightness();
		mseekBar.setProgress(size);
		mseekBar.SetValue(size + "");
	}

	/**
	 * 设置监听
	 */
	private OnSeekBarChangeListener mSeekChange = new OnSeekBarChangeListener() {
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		}

		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {
		}

		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			int progress = seekBar.getProgress();
			Logger.e(progress + "");
			mseekBar.SetValue(progress + "");
			mseekBar.setProgress(progress);
			setBrightness(progress);
		}
	};

	private void setBrightness(int brightness) {
		try {
			// mPower.setTemporaryScreenBrightnessSettingOverride(brightness);
		} catch (Exception ex) {
		}
		Settings.System.putInt(mContext.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, brightness);
	}

	private int getBrightness() {
		int brightness = 0;
		brightness = Settings.System.getInt(mContext.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 102);
		if (brightness == 10) {
			return 0;
		} else if (brightness == 255) {
			return 100;
		}
		return (int) ((brightness - 10) / 2.45);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.imgbt_auto_scree:

			break;
		case R.id.imgbt_scree_procter:
			startActivity(ScreeprocterActivity.class);
			break;
		case R.id.imgbt_wallpaper:
			startActivity(ScreeWallpaperActivity.class);
			break;
		case R.id.imgbt_theme:
			startActivity(ScreeThemeActivty.class);
			break;

		default:
			break;
		}
	}

	public void startActivity(Class class1) {
		Intent intent = new Intent(this, class1);
		startActivity(intent);
	}
}
