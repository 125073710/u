package com.tricheer.settings.common.screen;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;
import com.tricheer.settings.View.MyDialog;
import com.tricheer.settings.util.UtilSetting;

/**
 * 主题
 * 
 * @author yangbofeng
 * 
 */
public class ScreeThemeActivty extends BaseSubActivity {
	private RadioGroup radio_group_theme;
	private RadioButton radio_theme1, radio_theme2;
	private MyDialog dialog;
	private Context mContext;
	private int tag = 1;
	private int value = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_scree_theme);
		setTitleString(getResources().getString(R.string.common_theme));
		inintView();
		initData();
	}

	private void inintView() {
		// TODO Auto-generated method stub
		radio_group_theme = (RadioGroup) findViewById(R.id.radio_group_theme);
		radio_theme1 = (RadioButton) findViewById(R.id.radio_theme1);
		radio_theme2 = (RadioButton) findViewById(R.id.radio_theme2);
		radio_group_theme.setOnCheckedChangeListener(listener);
	}

	private void initData() {
		// TODO Auto-generated method stub
		value = UtilSetting.getdata(mContext, "theme_setting");
		Logger.e("[init]value="+value);
		if (value == 0) {
			value = 1;
			radio_theme1.setChecked(true);
		}
		switch (value) {
		case 1:
			radio_theme1.setChecked(true);
			break;
		case 2:
			radio_theme2.setChecked(true);
			break;
		}
	}

	OnCheckedChangeListener listener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			// TODO Auto-generated method stub
			switch (checkedId) {
			case R.id.radio_theme1:
				tag = 1;
				Logger.e("radio_theme1");
				break;
			case R.id.radio_theme2:
				tag =2;
				Logger.e("radio_theme2");
				break;
			}
		}
	};

	public void onBack() {
		Logger.e("value= " + value + "--tag= " + tag);
		if (value == tag) {
			finish();
		} else {
			showDialog();
		}
	}

	/**
	 * 显示提示框
	 */

	private void showDialog() {
		// TODO Auto-generated method stub

		dialog = new MyDialog(this);
		View view = LayoutInflater.from(this).inflate(R.layout.dialog_common, null);
		dialog.setLayoutView(view);
		Window window = dialog.getWindow();
		final WindowManager.LayoutParams p = window.getAttributes();
		p.gravity = Gravity.CENTER;
		p.width = 500;
		p.height = 300;
		window.setAttributes(p);
		window.setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
				WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();

		TextView tv_body = (TextView) view.findViewById(R.id.tv_body);
		TextView tv_yes = (TextView) view.findViewById(R.id.tv_yes);
		TextView tv_no = (TextView) view.findViewById(R.id.tv_no);
		tv_body.setText(R.string.scree_wallpaper_body);
		tv_yes.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				setTheme(tag);
			}
		});
		tv_no.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
				finish();
			}
		});
	};
	
	public void setTheme(int value){
		UtilSetting.setdata(mContext, "theme_setting", value);
	}
}
