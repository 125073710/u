package com.tricheer.settings.common.screen;

import java.io.IOException;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;
import com.tricheer.settings.View.MyDialog;
import com.tricheer.settings.util.UtilSetting;

/**
 * 壁纸
 * 
 * @author yangbofeng
 * 
 */
public class ScreeWallpaperActivity extends BaseSubActivity {
	private RadioGroup radio_group_wallpaper;
	private RadioButton radio_wallpaper1, radio_wallpaper2, radio_wallpaper3, radio_wallpaper4, radio_wallpaper5,
			radio_wallpaper6, radio_wallpaper7;
	private ImageView image_wallpaper;
	private WallpaperManager wpManager;
	private MyDialog dialog;
	private Context mContext;
	private int value = 0;
	private int tag = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setTitleString(getResources().getString(R.string.common_wallpaper));
		setContentView(R.layout.activity_scree_wallpaper);
		mContext = this;
		initView();
		initData();
	}

	private void initView() {
		// TODO Auto-generated method stub
		radio_group_wallpaper = (RadioGroup) findViewById(R.id.radio_group_wallpaper);
		radio_wallpaper1 = (RadioButton) findViewById(R.id.radio_wallpaper1);
		radio_wallpaper2 = (RadioButton) findViewById(R.id.radio_wallpaper2);
		radio_wallpaper3 = (RadioButton) findViewById(R.id.radio_wallpaper3);
		radio_wallpaper4 = (RadioButton) findViewById(R.id.radio_wallpaper4);
		radio_wallpaper5 = (RadioButton) findViewById(R.id.radio_wallpaper5);
		radio_wallpaper6 = (RadioButton) findViewById(R.id.radio_wallpaper6);
		radio_wallpaper7 = (RadioButton) findViewById(R.id.radio_wallpaper7);
		radio_group_wallpaper.setOnCheckedChangeListener(listener);

		image_wallpaper = (ImageView) findViewById(R.id.image_wallpaper);

		wpManager = WallpaperManager.getInstance(this);
	
		

	}

	private void initData() {
		// TODO Auto-generated method stub
		 value = UtilSetting.getShareperfer(mContext, "wallpapaer");
		 Logger.e("init tag = "+tag);
		if (value == 0) {
			value = 1;
			radio_wallpaper1.setChecked(true);

		}
		switch (value) {
		case 1:
			radio_wallpaper1.setChecked(true);
			break;
		case 2:
			radio_wallpaper2.setChecked(true);
			break;
		case 3:
			radio_wallpaper3.setChecked(true);
			break;
		case 4:
			radio_wallpaper4.setChecked(true);
			break;
		case 5:
			radio_wallpaper5.setChecked(true);
			break;
		case 6:
			radio_wallpaper6.setChecked(true);
			break;
		case 7:
			radio_wallpaper7.setChecked(true);
			break;
		}
	}

	OnCheckedChangeListener listener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			// TODO Auto-generated method stub
			switch (checkedId) {
			case R.id.radio_wallpaper1:
				tag = 1;
				Logger.e("wallpaper1");
				break;
			case R.id.radio_wallpaper2:
				tag = 2;
				Logger.e("wallpaper2");
				break;
			case R.id.radio_wallpaper3:
				tag = 3;
				Logger.e("wallpaper3");
				break;
			case R.id.radio_wallpaper4:
				tag = 4;
				Logger.e("wallpaper4");
				break;
			case R.id.radio_wallpaper5:
				tag = 5;
				Logger.e("wallpaper5");
				break;
			case R.id.radio_wallpaper6:
				tag = 6;
				Logger.e("wallpaper6");
				break;
			case R.id.radio_wallpaper7:
				tag = 7;
				Logger.e("wallpaper7");
				break;
			default:
				break;
			}
		}
	};

	public void onBack() {
		Logger.e("value= " + value + "--tag= " + tag);
		if (value == tag) {
			finish();
		} else {
			showDialog();
		}
	}

	/**
	 * 显示提示框
	 */

	private void showDialog() {
		// TODO Auto-generated method stub

		dialog = new MyDialog(this);
		View view = LayoutInflater.from(this).inflate(R.layout.dialog_common, null);
		dialog.setLayoutView(view);
		Window window = dialog.getWindow();
		final WindowManager.LayoutParams p = window.getAttributes();
		p.gravity = Gravity.CENTER;
		p.width = 500;
		p.height = 300;
		window.setAttributes(p);
		window.setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
				WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();

		TextView tv_body = (TextView) view.findViewById(R.id.tv_body);
		TextView tv_yes = (TextView) view.findViewById(R.id.tv_yes);
		TextView tv_no = (TextView) view.findViewById(R.id.tv_no);
		tv_body.setText(R.string.scree_wallpaper_body);
		tv_yes.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				setDrawer();
				dialog.dismiss();
				finish();
			}
		});
		tv_no.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
				finish();
			}
		});
	};

	private void setDrawer() {
		// TODO Auto-generated method stub
		switch (tag) {
		case 1:
			setWallpaper(1, R.drawable.set_bg);
			break;
		case 2:
			setWallpaper(2, R.drawable.bg);
			break;
		case 3:
			setWallpaper(3, R.drawable.set_bg);
			break;
		case 4:
			setWallpaper(4, R.drawable.bg);
			break;
		case 5:
			setWallpaper(5, R.drawable.set_bg);
			break;
		case 6:
			setWallpaper(6, R.drawable.bg);
			break;
		case 7:
			setWallpaper(7, R.drawable.set_bg);
			break;
		default:
			break;
		}
	}

	public void setWallpaper(int tag, int id) {
		try {
			UtilSetting.setShareprefer(mContext, "wallpapaer", tag);
			wpManager.setBitmap(BitmapFactory.decodeResource(getResources(), id));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
