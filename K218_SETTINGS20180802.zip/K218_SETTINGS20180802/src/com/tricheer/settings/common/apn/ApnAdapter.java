package com.tricheer.settings.common.apn;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.R;

public class ApnAdapter extends BaseAdapter {
	private ArrayList<APNBean> lists;
	private Context mContext;
	public int defaultSelection = 0;

	public ApnAdapter(Context mContext, ArrayList<APNBean> list) {
		this.mContext = mContext;
		this.lists = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lists.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder = null;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.apn_item, null);
			holder.tv_name = (TextView) convertView.findViewById(R.id.tv_name);
			holder.img_ok = (ImageView) convertView.findViewById(R.id.img_ok);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		holder.tv_name.setText(lists.get(position).getName());
		if (position == defaultSelection) {// 选中时设置单纯颜色
			holder.img_ok.setImageDrawable(mContext.getResources().getDrawable(R.drawable.readubutok));
		} else {// 未选中时设置selector
			holder.img_ok.setImageDrawable(mContext.getResources().getDrawable(R.drawable.readubut));
		}
		// Logger.e(lists.get(position).toString());
		return convertView;
	}

	final class ViewHolder {
		TextView tv_name;
		ImageView img_ok;
	}

	/**
	 * @param position
	 *            设置高亮状态的item
	 */
	public void setSelectPosition(int position) {
		if (!(position < 0 || position > lists.size())) {
			defaultSelection = position;
			notifyDataSetChanged();
		}
	}
}
