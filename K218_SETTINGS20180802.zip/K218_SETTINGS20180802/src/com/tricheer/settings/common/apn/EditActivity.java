package com.tricheer.settings.common.apn;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;

public class EditActivity extends BaseSubActivity implements OnClickListener {
	private int tag = 0;
	private Button activity_refresh;
	private EditText ed_edit;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		Intent intent = getIntent();
		tag = intent.getIntExtra("name", 0);
		setTitle();
		setContentView(R.layout.activity_apn_edit);
		initView();
	}

	private void initView() {
		// TODO Auto-generated method stub
		activity_refresh = (Button) findViewById(R.id.activity_refresh);
		activity_refresh.setVisibility(View.VISIBLE);
		activity_refresh.setBackgroundDrawable(getResources().getDrawable(R.drawable.x));
		activity_refresh.setOnClickListener(this);
		ed_edit = (EditText) findViewById(R.id.ed_edit);
	}

	/**
	 * 设置title
	 */
	public void setTitle() {
		Logger.e("tag =" + tag);
		switch (tag) {
		case 1:
			setTitleString(getResources().getString(R.string.name));
			break;
		case 2:
			setTitleString(getResources().getString(R.string.apn));
			break;
		case 3:
			setTitleString(getResources().getString(R.string.user_name));
			break;
		case 4:
			setTitleString(getResources().getString(R.string.password));
			break;
		case 5:
			setTitleString(getResources().getString(R.string.server));
			break;
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.activity_refresh:

			finish();
			break;
		}
	}

	@Override
	public void finish() {
		// TODO Auto-generated method stub
		Intent intent1 = new Intent();
		intent1.putExtra("data", ed_edit.getText().toString());
		setResult(tag, intent1);
		super.finish();

	}
}