package com.tricheer.settings.common.apn;

public class APNBean {
	private String id;
	private String name;
	private String Apn;

	public String getApn() {
		return Apn;
	}

	public void setApn(String apn) {
		Apn = apn;
	}

	private String Type;

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
