package com.tricheer.settings.common.apn;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ListView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;

public class ApnActivity extends BaseSubActivity {
	private ListView lv_apn;
	private View footView;
	private ImageButton imgabt;
	private ApnAdapter adapter;
	private Context mContext;
	private ArrayList<APNBean> list = new ArrayList<APNBean>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setTitleString(getResources().getString(R.string.common_APN));
		setContentView(R.layout.activity_apn);
		mContext = getApplicationContext();
		initView();
		initData();
	}

	private void initView() {
		// TODO Auto-generated method stub
		lv_apn = (ListView) findViewById(R.id.lv_apn);
	//	list = getAPNList();
		adapter = new ApnAdapter(mContext, list);
		lv_apn.setAdapter(adapter);
		// 将layout的内容加入到listView当中去
		footView = getLayoutInflater().inflate(R.layout.add_apn_view, null);
		lv_apn.addFooterView(footView);
		imgabt = (ImageButton) footView.findViewById(R.id.imgbt);
		imgabt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(NewAddApnActiivty.class);
			}
		});
	}
	public void startActivity(Class class1) {
		Intent intent = new Intent(this, class1);
		startActivity(intent);
	}

	private void initData() {
		// TODO Auto-generated method stub
	

	}

	public ArrayList<APNBean> getAPNList() {
		final Uri CURRENT_APN_URI = Uri.parse("content://telephony/carriers/current");
		Cursor cr = this.getContentResolver().query(CURRENT_APN_URI, null, null, null, null);
		String[] mStrings = new String[cr.getCount()];
		int i = 0;
		while (cr != null && cr.moveToNext()) {
			mStrings[i] = "ID:" + cr.getString(cr.getColumnIndex("_id")) + "\n" + "name:"
					+ cr.getString(cr.getColumnIndex("name")) + "\n" + "numeric:"
					+ cr.getString(cr.getColumnIndex("numeric")) + "\n" + "mcc:"
					+ cr.getString(cr.getColumnIndex("mcc")) + "\n" + "mnc:" + cr.getString(cr.getColumnIndex("mnc"))
					+ "\n" + "apn:" + cr.getString(cr.getColumnIndex("apn")) + "\n" + "user:"
					+ cr.getString(cr.getColumnIndex("user")) + "\n" + "server:"
					+ cr.getString(cr.getColumnIndex("server")) + "\n" + "password:"
					+ cr.getString(cr.getColumnIndex("password")) + "\n" + "proxy:"
					+ cr.getString(cr.getColumnIndex("proxy")) + "\n" + "port:"
					+ cr.getString(cr.getColumnIndex("port")) + "\n" + "mmsproxy:"
					+ cr.getString(cr.getColumnIndex("mmsproxy")) + "\n" + "mmsport:"
					+ cr.getString(cr.getColumnIndex("mmsport")) + "\n" + "mmsc:"
					+ cr.getString(cr.getColumnIndex("mmsc")) + "\n" + "authtype:"
					+ cr.getString(cr.getColumnIndex("authtype")) + "\n" + "type:"
					+ cr.getString(cr.getColumnIndex("type")) + "\n" + "current:"
					+ cr.getString(cr.getColumnIndex("current"));
			Logger.e(mStrings[i]);
			APNBean a = new APNBean();

			a.setId(cr.getString(cr.getColumnIndex("_id")));
			a.setApn(cr.getString(cr.getColumnIndex("apn")));
			a.setName(cr.getString(cr.getColumnIndex("name")));
			a.setType(cr.getString(cr.getColumnIndex("type")));
			list.add(a);
			i++;
		}
		if (cr != null)
			cr.close();
		Logger.e(list.size() + "");
		return list;
	}

	private ArrayList<APNBean> getAPN() {
		final Uri PREFERRED_APN_URI = Uri.parse("content://telephony/carriers/preferapn");
		final Uri countApn = Uri.parse("content://telephony/carriers/current");
		// current不为空表示可以使用的APN
		String projection[] = { "_id,apn,type,current" };
		list.clear();
		Cursor cr = this.getContentResolver().query(countApn, projection, null, null, null);
		while (cr != null && cr.moveToNext()) {
			Logger.e(cr.getString(cr.getColumnIndex("_id")) + "\n" + cr.getString(cr.getColumnIndex("apn")) + "\n"
					+ cr.getString(cr.getColumnIndex("type")) + "\n" + cr.getString(cr.getColumnIndex("current"))
					+ cr.getString(cr.getColumnIndex("carrier")));
			APNBean a = new APNBean();

			a.setId(cr.getString(cr.getColumnIndex("_id")));
			a.setApn(cr.getString(cr.getColumnIndex("apn")));
			a.setName(cr.getString(cr.getColumnIndex("carrier")));
			a.setType(cr.getString(cr.getColumnIndex("type")));
			list.add(a);

		}
		if (cr != null)
			cr.close();
		Logger.e(list.size() + "");
		return list;
	}
}
