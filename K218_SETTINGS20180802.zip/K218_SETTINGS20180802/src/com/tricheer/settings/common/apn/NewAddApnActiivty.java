package com.tricheer.settings.common.apn;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;
import com.tricheer.settings.View.MyDialog;

public class NewAddApnActiivty extends BaseSubActivity implements OnClickListener {
	private RelativeLayout rl_apn_name, rl_apn_apn, rl_apn_username, rl_anp_password, rl_apn_server;
	private MyDialog dialog;
	private TextView tv_apn_name, tv_apn_apn, tv_apn_username, tv_anp_password, tv_apn_server;
	private TextView tv_apn_apn_n, tv_apn_name_n, tv_apn_username_n, tv_anp_password_n, tv_apn_server_n;
	private EditText ed_apn;
	private Button activity_refresh;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setTitleString(getResources().getString(R.string.apn));
		setContentView(R.layout.activity_new_add_apn);
		initView();
	}

	private void initView() {
		// TODO Auto-generated method stub
		rl_apn_name = (RelativeLayout) findViewById(R.id.rl_apn_name);
		rl_apn_apn = (RelativeLayout) findViewById(R.id.rl_apn_apn);
		rl_apn_username = (RelativeLayout) findViewById(R.id.rl_apn_username);
		rl_anp_password = (RelativeLayout) findViewById(R.id.rl_anp_password);
		rl_apn_server = (RelativeLayout) findViewById(R.id.rl_apn_server);
		rl_apn_name.setOnClickListener(this);
		rl_apn_apn.setOnClickListener(this);
		rl_apn_username.setOnClickListener(this);
		rl_anp_password.setOnClickListener(this);
		rl_apn_server.setOnClickListener(this);
		tv_apn_name = (TextView) findViewById(R.id.tv_apn_name);
		tv_apn_apn = (TextView) findViewById(R.id.tv_apn_apn);
		tv_apn_username = (TextView) findViewById(R.id.tv_apn_username);
		tv_anp_password = (TextView) findViewById(R.id.tv_anp_password);
		tv_apn_server = (TextView) findViewById(R.id.tv_apn_server);
		tv_apn_apn_n = (TextView) findViewById(R.id.tv_apn_apn_n);
		tv_anp_password_n = (TextView) findViewById(R.id.tv_anp_password_n);
		tv_apn_username_n = (TextView) findViewById(R.id.tv_apn_username_n);
		tv_apn_name_n = (TextView) findViewById(R.id.tv_apn_name_n);
		tv_apn_server_n = (TextView) findViewById(R.id.tv_apn_server_n);
		activity_refresh = (Button) findViewById(R.id.activity_refresh);
		activity_refresh.setVisibility(View.VISIBLE);
		activity_refresh.setBackgroundDrawable(getResources().getDrawable(R.drawable.x));
		activity_refresh.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.rl_apn_name:
			// showDialog(tv_apn_name, tv_apn_name_n.getText().toString());
			startActivity(EditActivity.class, 1);
			Logger.e(tv_apn_name_n.getText().toString());
			break;
		case R.id.rl_apn_apn:
			startActivity(EditActivity.class, 2);
			break;
		case R.id.rl_apn_username:
			startActivity(EditActivity.class, 3);
			break;
		case R.id.rl_anp_password:
			startActivity(EditActivity.class, 4);
			break;
		case R.id.rl_apn_server:
			startActivity(EditActivity.class, 5);
			break;
		case R.id.activity_refresh:
			finish();
			break;
		}
	}

	public void startActivity(Class class1, int requestCode) {
		Intent intent = new Intent(this, class1);
		intent.putExtra("name", requestCode);
		startActivityForResult(intent, requestCode);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		Logger.e(requestCode + "");
		Logger.e(data.getStringExtra("data"));
		switch (requestCode) {
		case 1:
			Logger.e(data.getStringExtra("data") + "");
			tv_apn_name.setText(data.getStringExtra("data"));
			break;
		case 2:
			tv_apn_apn.setText(data.getStringExtra("data"));
			break;
		case 3:
			tv_apn_username.setText(data.getStringExtra("data"));
			break;
		case 4:
			tv_anp_password.setText(data.getStringExtra("data"));
			break;
		case 5:
			tv_apn_server.setText(data.getStringExtra("data"));
			break;
		}
	
	}

	/**
	 * 显示提示框
	 */

	private void showDialog(final TextView tv, final String tv_n) {
		Logger.e(tv_n);

		// TODO Auto-generated method stub
		dialog = new MyDialog(this);
		View view = LayoutInflater.from(this).inflate(R.layout.apn_add_item, null);
		dialog.setLayoutView(view);
		Window window = dialog.getWindow();
		final WindowManager.LayoutParams p = window.getAttributes();
		p.gravity = Gravity.CENTER;
		p.width = 600;
		p.height = 180;
		window.setAttributes(p);
		window.setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
				WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();

		final EditText tv_body = (EditText) view.findViewById(R.id.tv_body);
		final TextView tv_apn_name_nn = (TextView) view.findViewById(R.id.tv_apn_name_nn);
		tv_apn_name_nn.setText(tv_n);
		TextView tv_yes = (TextView) view.findViewById(R.id.tv_yes);
		TextView tv_no = (TextView) view.findViewById(R.id.tv_no);
		tv_body.setText(tv_body.getText().toString());
		tv_body.setText(tv.getText().toString());
		tv_body.setSelection(tv_body.getText().toString().length());
		tv_yes.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				tv.setText(tv_body.getText().toString());
				InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(tv_body.getWindowToken(), 0);
				dialog.dismiss();
			}
		});
		tv_no.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
	};

}
