package com.tricheer.settings.common;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

import com.orhanobut.logger.Logger;
import com.tricheer.settings.BaseSubActivity;
import com.tricheer.settings.R;
/**
 * 倒车延时
 * @author yangbofeng
 *
 */
public class CarBackDelayActivity extends BaseSubActivity {
	private RadioGroup radio_group_car_back;
	private RadioButton radio_car_back_0s, radio_car_back_5s, radio_car_back_10s, radio_car_back_15s;
	private int tag = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setTitleString(getResources().getString(R.string.car_back_delay));
		setContentView(R.layout.activity_car_back_delay);
		initView();
	}

	public void initView() {
		radio_group_car_back = (RadioGroup) findViewById(R.id.radio_group_car_back);
		radio_group_car_back.setOnCheckedChangeListener(listener);
		radio_car_back_0s = (RadioButton) findViewById(R.id.radio_car_back_0s);
		radio_car_back_5s = (RadioButton) findViewById(R.id.radio_car_back_5s);
		radio_car_back_10s = (RadioButton) findViewById(R.id.radio_car_back_10s);
		radio_car_back_15s = (RadioButton) findViewById(R.id.radio_car_back_15s);
	}

	OnCheckedChangeListener listener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			// TODO Auto-generated method stub
			switch (checkedId) {
			case R.id.radio_car_back_0s:
				tag = 1;
				Logger.e("0S");
				break;
			case R.id.radio_car_back_5s:
				tag = 2;
				Logger.e("5S");
				break;
			case R.id.radio_car_back_10s:
				tag = 3;
				Logger.e("10S");
				break;
			case R.id.radio_car_back_15s:
				tag = 4;
				Logger.e("15S");
				break;
			}
		}
	};
}
