package com.tricheer.settings.common;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.tricheer.settings.R;
import com.tricheer.settings.View.MyDialog;
import com.tricheer.settings.common.apn.ApnActivity;
import com.tricheer.settings.common.date.DateAndTiemActivity;
import com.tricheer.settings.common.screen.ScreeShowSetActivity;
import com.tricheer.settings.fragment.BaseFragment;
import com.tricheer.settings.util.UtilSetting;

/**
 * 通用设置UI 直接进入使用intent.putExtra("launch","common")
 * 
 */
public class CommonFragment extends BaseFragment implements OnClickListener {
	private View mView;
	private static String TAG = "DialFragment";
	public static final int INDEX = 0;
	private MyDialog dialog;
	private ImageButton imgbt_common_show_warning;
	private RelativeLayout rl_screen, rl_car_back, rl_date, rl_apn, rl_reboot, rl_recover;
	boolean isopen = true;


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		mView = inflater.inflate(R.layout.frag_layout_common, container, false);
		initView();
		return mView;
	}

	private void initView() {
		rl_screen = (RelativeLayout) mView.findViewById(R.id.rl_screen);
		rl_car_back = (RelativeLayout) mView.findViewById(R.id.rl_car_back);
		rl_date = (RelativeLayout) mView.findViewById(R.id.rl_date);
		rl_apn = (RelativeLayout) mView.findViewById(R.id.rl_apn);
		rl_reboot = (RelativeLayout) mView.findViewById(R.id.rl_reboot);
		rl_recover = (RelativeLayout) mView.findViewById(R.id.rl_recover);
		imgbt_common_show_warning = (ImageButton) mView.findViewById(R.id.imgbt_common_show_warning);
		imgbt_common_show_warning.setOnClickListener(this);
		rl_screen.setOnClickListener(this);
		rl_car_back.setOnClickListener(this);
		rl_date.setOnClickListener(this);
		rl_apn.setOnClickListener(this);
		rl_reboot.setOnClickListener(this);
		rl_recover.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.rl_screen:
			startActivity(ScreeShowSetActivity.class);
			break;
		case R.id.rl_car_back:
			startActivity(CarBackDelayActivity.class);
			break;
		case R.id.rl_date:
			startActivity(DateAndTiemActivity.class);
			break;
		case R.id.rl_apn:
			startActivity(ApnActivity.class);
			break;
		case R.id.rl_reboot:
			showDialogReboot();
			break;
		case R.id.rl_recover:
			showDialogReseat();
			break;
		case R.id.imgbt_common_show_warning:
			if(isopen){
				imgbt_common_show_warning.setImageDrawable(getActivity().getResources().getDrawable(R.drawable.btn_open));
				UtilSetting.setdata(getActivity(), "open_waring", 1);
				isopen = false;
			}else{
				imgbt_common_show_warning.setImageDrawable(getActivity().getResources().getDrawable(R.drawable.btn_close));
				UtilSetting.setdata(getActivity(), "open_waring", 0);
				isopen = true;
			}
			break;
		}
	};

	/**
	 * 显示提示框 重启
	 */

	private void showDialogReboot() {
		// TODO Auto-generated method stub

		dialog = new MyDialog(getActivity());
		View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_common, null);
		dialog.setLayoutView(view);
		Window window = dialog.getWindow();
		final WindowManager.LayoutParams p = window.getAttributes();
		p.gravity = Gravity.CENTER;
		p.width = 500;
		p.height = 300;
		window.setAttributes(p);
		window.setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
				WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();

		TextView tv_body = (TextView) view.findViewById(R.id.tv_body);
		TextView tv_yes = (TextView) view.findViewById(R.id.tv_yes);
		TextView tv_no = (TextView) view.findViewById(R.id.tv_no);
		tv_body.setText(R.string.reboot);
		tv_yes.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent2 = new Intent(Intent.ACTION_REBOOT);
				intent2.putExtra("nowait", 1);
				getActivity().sendBroadcast(intent2);
			}
		});
		tv_no.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
	};
	/**
	 * 恢复出厂设置
	 */
	private void showDialogReseat() {
		// TODO Auto-generated method stub

		dialog = new MyDialog(getActivity());
		View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_common, null);
		dialog.setLayoutView(view);
		Window window = dialog.getWindow();
		final WindowManager.LayoutParams p = window.getAttributes();
		p.gravity = Gravity.CENTER;
		p.width = 500;
		p.height = 300;
		window.setAttributes(p);
		window.setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
				WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
		dialog.setCanceledOnTouchOutside(false);
		dialog.show();

		TextView tv_body = (TextView) view.findViewById(R.id.tv_body);
		TextView tv_yes = (TextView) view.findViewById(R.id.tv_yes);
		TextView tv_no = (TextView) view.findViewById(R.id.tv_no);
		tv_body.setText(R.string.reseat);
		tv_yes.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent("android.intent.action.MASTER_CLEAR");
				intent.addFlags(Intent.FLAG_RECEIVER_FOREGROUND);
				intent.putExtra("android.intent.extra.REASON", "MasterClearConfirm");
				getActivity().sendBroadcast(intent);
				// getActivity().sendBroadcast(new
				// Intent("android.intent.action.MASTER_CLEAR"));
			}
		});
		tv_no.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
	};

	public void startActivity(Class class1) {
		Intent intent = new Intent(getActivity(), class1);
		startActivity(intent);
	}

}
