package com.tricheer.settings.wifi;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tricheer.settings.R;
import com.tricheer.settings.fragment.BaseFragment;
/**
 * WIFI设置UI 直接进入使用intent.putExtra("launch","wifi")
 *
 */
public class WifiFragment extends BaseFragment{
	private View mView;
	private static String TAG = "WifiFragment";
	public static final int INDEX = 1;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		mView = inflater.inflate(R.layout.frag_layout_wifi, container,
				false);
//		initView();
		return mView;
	}


}
