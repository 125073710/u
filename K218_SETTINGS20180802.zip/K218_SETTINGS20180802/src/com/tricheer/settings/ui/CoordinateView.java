package com.tricheer.settings.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.view.View;

public class CoordinateView extends View{
    private float m_cx = 0;
    private float m_cy = 0;
    private float m_radius = 12; 
    private Paint paint;
    private Paint linePaint ;
    private float h_stopY;
    private float h_stopX;
    private float h_startX;
    private float h_startY;
    private float v_stopY;
    private float v_stopX;
    private float v_startX;
    private float v_startY;   
    public CoordinateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStyle(Style.FILL);
        linePaint = new Paint();
        linePaint.setColor(Color.WHITE);
        linePaint.setStyle(Style.FILL);
    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if(m_cx!=0 && m_cy !=0){
            canvas.drawCircle(m_cx, m_cy, m_radius, paint);
        }
        canvas.drawLine(h_startX, h_startY, h_stopX, h_stopY, linePaint);
        canvas.drawLine(v_startX, v_startY, v_stopX, v_stopY, linePaint);
    }
    public void setInvalidate(float x , float y){
        m_cx = x;
        m_cy = y;
        invalidate();
    }
    public void setHLine(float startX ,float startY ,float stopX , float stopY){
        h_startX = startX ;
        h_startY = startY ;
        h_stopX = stopX ;
        h_stopY = stopY ;
    }
    public void setVLine(float startX ,float startY ,float stopX , float stopY){
        v_startX = startX ;
        v_startY = startY ;
        v_stopX = stopX ;
        v_stopY = stopY ;
    }
}
